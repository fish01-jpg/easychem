# Easy Chem | TI-84 Evo Python
from math import log, log10, exp, sqrt
try:
  from ti_system import disp_clr
except ImportError:
  def disp_clr():
    print("")

DIG = "0123456789"
ABC = "abcdefg"
BAR = "--------------------------"
ROUND_EVEN = False
U = {
  "v": ("L mL uL cm3 m3", (1, .001, .000001, .001, 1000)),
  "p": ("atm kPa Pa bar mmHg torr", (1, .009869232667, .000009869232667,
                  .9869232667, .001315789474, .001315789474)),
  "t": ("K C F", (1, 1, 5/9)),
  "d": ("C K F", (1, 1, 5/9)),
  "m": ("g mg kg ug", (1, .001, 1000, .000001)),
  "n": ("mol mmol umol", (1, .001, .000001)),
  "c": ("mol/L mmol/L", (1, .001)),
  "b": ("mol/kg", (1,)),
  "w": ("g/mol kg/mol", (1, 1000)),
  "q": ("J kJ cal", (1, 1000, 4.184)),
  "h": ("J/mol kJ/mol", (1, 1000)),
  "s": ("J/mol/K kJ/mol/K", (1, 1000)),
  "j": ("J/g/K", (1,)),
  "C": ("J/K kJ/K", (1, 1000)),
  "D": ("g/mL g/L kg/m3", (1, .001, .001)),
  "G": ("g/L g/mL kg/m3", (1, 1000, 1)),
  "l": ("m nm um cm", (1, 1e-9, 1e-6, .01)),
  "f": ("Hz kHz MHz GHz", (1, 1000, 1e6, 1e9)),
  "z": ("s min h day yr", (1, 60, 3600, 86400, 31557600)),
  "V": ("V mV", (1, .001)),
  "I": ("A mA", (1, .001)),
  "Q": ("Coulomb", (1,)),
  "L": ("L/mol/cm", (1,)),
  "B": ("cm mm m", (1, .1, 100)),
  "%": ("%", (1,)),
  "X": ("entities", (1,)),
  "P": ("ppm ppb", (1, .001)),
  "0": ("", (1,))
}
# Normalized units for constants are stated in each guide.
CONST = {
  "R": .08205736608, "RJ": 8.314462618, "NA": 6.02214076e23,
  "H": 6.62607015e-34, "LIGHT": 299792458, "F": 96485.33212,
  "L2": .69314718056
}

# Tool: title, symbol names, unit codes, product law or (formula, RPNs), guide.
# ! positive, + nonnegative, # positive integer, @ 0..100, & 0..1.
# A unit code without a prefix permits signed values (except temperatures).
GAS = (
  ("Charles: V and T", "V1 V2 T1 T2", "!v !v !t !t", "a/c=b/d",
   "Pressure and moles stay fixed. State 1 is before; state 2 is after. Temperatures are converted to K."),
  ("Boyle: P and V", "P1 P2 V1 V2", "!p !p !v !v", "ac=bd",
   "Temperature and moles stay fixed. State 1 is before; state 2 is after. Enter absolute pressure."),
  ("Gay-Lussac: P and T", "P1 P2 T1 T2", "!p !p !t !t", "a/c=b/d",
   "Volume and moles stay fixed. Also called Amontons's law. Use absolute pressure and kelvin temperatures."),
  ("Combined gas law", "P1 P2 V1 V2 T1 T2", "!p !p !v !v !t !t", "ac/e=bd/f",
   "Use for two states of the SAME amount of gas. Absolute pressure and kelvin temperatures are required."),
  ("Ideal gas law", "P V n T", "!p !v !n !t", "ab=cRd",
   "Use absolute P, gas volume V, amount n and temperature T. R is 0.08205737 L*atm/(mol*K)."),
  ("Avogadro: V and n", "V1 V2 n1 n2", "!v !v !n !n", "a/c=b/d",
   "Pressure and temperature stay fixed; V is volume and n is moles."),
  ("Dalton: add pressures", "", "", "",
   ""),
  ("Partial pressure", "Ppart X Ptotal", "+p &0 !p", "a=bc",
   "Ppart is the gas's partial pressure; X is its mole fraction (0 to 1). Ptotal is absolute total pressure."),
  ("Gas density", "d P MM T", "!G !p !w !t", "a=bc/Rd",
   "Ideal gas only. d is density and MM is molar mass. R uses L, atm, mol and K."),
  ("Graham: effusion", "rateA/B MMA MMB", "!0 !w !w",
   ("rateA/B = sqrt(MMB / MMA)", "c b / sqrt", "c a a * /", "b a a * *"),
   "Use the rate of A divided by the rate of B. MMA and MMB are molar masses; compare at the same temperature."),
  ("Gas molar mass", "P V mass T MM", "!p !v !m !t !w", "ab=Rcd/e",
   "Ideal gas only. Uses absolute pressure, volume, mass and temperature. R uses L, atm, mol and K.")
)
MOLES = (
  ("Mass and moles", "mass n MM", "+m +n !w", "a=bc",
   "Enter sample mass, amount in moles or molar mass MM. Use Molar mass formula if needed."),
  ("Moles and particles", "N n", "+X +n", "a=bN",
   "N is number of specified entities (atoms, molecules, ions or formula units). NA is Avogadro's constant."),
  ("Density", "density mass V", "!D !m !v", "a=b/Uc",
   "Density uses g/mL internally; U = 1000 mL/L. Enter mass and the volume of the same sample."),
  ("Mole ratio", "nA nB coefA coefB", "+n +n #0 #0", "a/c=b/d",
   "A and B are two substances. Use their whole-number coefficients from a balanced reaction."),
  ("Grams to grams", "massA massB MMA MMB coefA coefB", "+m +m !w !w #0 #0",
   "a/ce=b/df",
   "Use a balanced equation. MM is molar mass. Assumes complete reaction; use Limiting reactant if both reactant amounts are given."),
  ("Limiting reactant", "", "", "", ""),
  ("Percent yield", "yield% actual theory", "+% +m !m", "a=Pb/c",
   "Actual and theoretical yields must describe the same product. Values over 100% are possible for impure or wet product."),
  ("Mass composition", "% part total", "@% +m !m", "a=Pb/c",
   "Part is the mass of the element or component. Total is the mass of the entire compound or sample."),
  ("Molar mass formula", "", "", "", ""),
  ("Formula multiplier", "factor molecular empirical", "#0 !w !w", "a=b/c",
   "Factor multiplies every empirical-formula subscript. Checks that the mass ratio is within 0.03 of a whole number.")
)
SOLN = (
  ("Molarity", "M n V", "+c +n !v", "a=b/c",
   "Use moles of solute and TOTAL solution volume, not solvent volume."),
  ("Dilution", "M1 M2 V1 V2", "!c !c !v !v", "ac=bd",
   "Solute amount stays constant. 1 is stock; 2 is final solution. V2 is final volume, NOT solvent added."),
  ("Titration", "MA MB VA VB coefA coefB", "!c !c !v !v #0 #0", "ac/e=bd/f",
   "At equivalence, moles divided by coefficients are equal. Use the balanced reaction, not M1V1 = M2V2 unless the ratio is 1:1."),
  ("pH and H3O+", "pH H3O+", "0 !c", ("pH = -log10(H3O+)", "b lg neg", "10 a neg ^"),
   "Enter hydronium concentration (mol/L in the formula). This classroom calculation uses concentration in place of activity."),
  ("pOH and OH-", "pOH OH-", "0 !c", ("pOH = -log10(OH-)", "b lg neg", "10 a neg ^"),
   "Enter hydroxide concentration (mol/L in the formula)."),
  ("pH + pOH = 14", "pH pOH", "0 0", ("pH + pOH = 14", "14 b -", "14 a -"),
   "For water at 25 C. At other temperatures use the actual pKw in pH + pOH = pKw."),
  ("Buffer pH", "pH pKa base acid", "0 0 !c !c",
   ("pH = pKa + log10(base/acid)", "b c d / lg +", "a c d / lg -",
    "d 10 a b - ^ *", "c 10 a b - ^ /"),
   "Henderson-Hasselbalch: base and acid are a conjugate pair. Use amounts AFTER any neutralization, as molarity."),
  ("Molality", "b n solvent", "+b +n !m", "a=Ub/c",
   "b is mol/kg, n is moles of solute, solvent is mass of SOLVENT only. U = 1000 g/kg."),
  ("Mole fraction", "X nPart nTotal", "&0 +n !n", "a=b/c",
   "Use moles of the component divided by total moles of all components."),
  ("Mass percent", "% solute solution", "@% +m !m", "a=Pb/c",
   "Use mass of solute and total mass of solution."),
  ("Volume percent", "% solute solution", "@% +v !v", "a=Pb/c",
   "Use solute volume and final solution volume (not a sum of separate volumes unless stated)."),
  ("Mass ppm / ppb", "ppm solute solution", "+P +m !m", "a=Mb/c",
   "Mass ratio, not mg/L. M = 1000000 for ppm. Can enter or display ppb."),
  ("Ka, Kb and Kw", "Ka Kb Kw", "!0 !0 !0", "ab=c",
   "Ka and Kb must be for a conjugate acid-base pair. Enter Kw for your temperature (1e-14 at 25 C)."),
  ("pKa and Ka", "pKa Ka", "0 !0", ("pKa = -log10(Ka)", "b lg neg", "10 a neg ^"),
   "Also works for pKb and Kb: use the same relationship with the base constant."),
  ("Weak acid (1 proton)", "", "", "", ""),
  ("Mass/volume percent", "% solute solution", "+% +m !v", "a=b/Wc",
   "Grams of solute per 100 mL of total solution. W = 10 for converting solution volume from L to units of 100 mL."),
  ("pH + pOH = pKw", "pH pOH pKw", "0 0 0",
   ("pH + pOH = pKw", "c b -", "c a -", "a b +"),
   "Use pKw for your temperature. If given Kw, use pKw = -log10(Kw). At 25 C, pKw is about 14."),
)
HEAT = (
  ("Heat: q = mc*dT", "q mass c dT", "q !m !j d", "a=bcd",
   "No phase change. c is specific heat. dT is final minus initial. Heating q > 0; cooling q < 0."),
  ("Change in temperature", "dT Tfinal Tstart", "d t t", ("dT = Tfinal - Tstart", "b c -", "a c +", "b a -"),
   "Enter absolute start/end temperatures. dT is a change, so do not add 273.15 to it."),
  ("Heat capacity", "q C dT", "q !C d", "a=bc",
   "C is heat capacity of the entire sample or calorimeter, not specific heat per gram."),
  ("Phase change / mol", "q n dH", "q +n h", "a=bc",
   "No temperature change during the phase step. Enter signed molar enthalpy for the direction: melting +, freezing -."),
  ("Gibbs free energy", "dG dH T dS", "h h !t s",
   ("dG = dH - T * dS", "b c d * -", "a c d * +", "b a - d /", "b a - c /"),
   "Use values for the same reaction basis. Entropy is normalized to J/mol/K; energies to J/mol."),
  ("Entropy: qrev / T", "dS qrev T", "s h !t", "a=b/c",
   "Reversible isothermal heat per mole divided by kelvin temperature. Keep the same molar basis."),
  ("First law: dU = q+w", "dU q w", "q q q", ("dU = q + w", "b c +", "a c -", "a b -"),
   "Use the chemistry sign convention: q positive into the system, w positive for work ON the system."),
  ("Pressure-volume work", "work Pext dV", "q !p v",
   ("work = -101.325*Pext*dV", "101.325 neg b * c *", "a 101.325 c * neg /", "a 101.325 b * neg /"),
   "Constant external pressure only. dV is Vfinal - Vinitial. Uses 101.325 J per L*atm."),
  ("Bond energy estimate", "dH broken formed", "h +h +h",
   ("dH = broken - formed", "b c -", "a c +", "b a -"),
   "Enter the sums of bond energies for bonds broken and formed per mole of reaction. Gas-phase estimate.")
)
RATE = (
  ("Zero-order rate", "At A0 k time", "+c !c +0 +z",
   ("At = A0 - k * time", "b c d * -", "a c d * +", "b a - d /", "b a - c /"),
   "One reactant, zero order. Concentrations in mol/L, k in mol/L/s. Use only before or at depletion."),
  ("First-order rate", "At A0 k time", "!c !c +0 +z",
   ("ln(At/A0) = -k * time", "b c d * neg exp *", "a c d * exp *",
    "b a / ln d /", "b a / ln c /"),
   "One reactant, first order. Concentrations in mol/L, k in 1/s."),
  ("Second-order rate", "At A0 k time", "!c !c +0 +z",
   ("1/At = 1/A0 + k * time", "1 1 b / c d * + /", "1 1 a / c d * - /",
    "1 a / 1 b / - d /", "1 a / 1 b / - c /"),
   "One reactant with rate k[A]^2. Concentrations in mol/L, k in L/mol/s."),
  ("Half-life: 1st order", "tHalf k", "!z !0", "ab=L",
   "First-order process, including basic radioactive decay. Enter k in 1/s. L = ln(2)."),
  ("Half-life: 0 order", "tHalf A0 k", "!z !c !0", "a= b/Tc",
   "Zero order. Use initial A0 in mol/L and k in mol/L/s. T is the factor 2."),
  ("Half-life: 2nd order", "tHalf A0 k", "!z !c !0", "abc=I",
   "Second order with rate k[A]^2. A0 is in mol/L, k in L/mol/s. I is the number 1."),
  ("Arrhenius", "k A Ea T", "!0 !0 h !t",
   ("k = A * exp(-Ea/(RJ*T))", "b c RJ d * / neg exp *", "a c RJ d * / exp *",
    "b a / ln RJ d * *", "c RJ b a / ln * /"),
   "k and pre-factor A use the same units. Ea is activation energy. RJ = 8.314462618 J/mol/K."),
  ("Kp and Kc", "Kp Kc T dnGas", "!0 !0 !t 0",
   ("Kp = Kc * (R*T)^dnGas", "b R c * d ^ *", "a R c * d ^ /",
    "a b / 1 d / ^ R /", "a b / ln R c * ln /"),
   "dnGas is gaseous product coefficients minus gaseous reactant coefficients. Use classroom atm and mol/L convention."),
  ("Gibbs and equilibrium", "dG0 K T", "h !0 !t",
   ("dG0 = -RJ * T * ln(K)", "RJ c * b ln * neg", "a RJ c * / neg exp", "a RJ b ln * / neg"),
   "Standard Gibbs free energy and equilibrium constant K, at the same temperature. Use natural log."),
  ("Compare Q and K", "", "", "", ""),
  ("Ksp and solubility", "", "", "", "")
)
MORE = (
  ("Light: wavelength/freq", "wave freq", "!l !f", "ab=S",
   "For light in vacuum. S = 299792458 m/s. Wavelength and frequency are inversely proportional."),
  ("Photon energy", "E freq", "!q !f", "a=Hb",
   "Use energy per photon, not energy per mole. H is Planck's constant in J*s."),
  ("Photon E/wavelength", "E wave", "!q !l", "ab=HS",
   "For light in vacuum. Energy is per photon. H is Planck's constant; S is the speed of light."),
  ("Beer-Lambert", "Abs eps path conc", "+0 !L !B +c", "a=bcd",
   "Abs is absorbance. eps is molar absorptivity in L/mol/cm, path is cuvette path length and conc is molarity."),
  ("Cell voltage", "Ecell Ecath Ean", "V V V", ("Ecell = Ecath - Ean", "b c -", "a c +", "b a -"),
   "Enter both half-cell values as reduction potentials. Do NOT multiply the potentials by coefficients."),
  ("Cell free energy", "dG n E", "h #0 V",
   ("dG = -n * F * E", "b F * c * neg", "a F c * / neg", "a F b * / neg"),
   "n is electrons transferred in the balanced reaction. F is Faraday's constant in C/mol. Consistent standard/nonstandard states."),
  ("Nernst equation", "E E0 n T Q", "V V #0 !t !0",
   ("E = E0 - RJ*T*ln(Q)/(n*F)", "b RJ d * e ln * c F * / -",
    "a RJ d * e ln * c F * / +", "RJ d * e ln * b a - F * /",
    "b a - c F * * RJ e ln * /", "b a - c F * * RJ d * / exp"),
   "Q is reaction quotient, n is electrons transferred, E0 is standard cell potential. Uses natural log and kelvin."),
  ("Electric charge", "Q current time", "+Q +I +z", "a=bc",
   "Q is charge, current in amperes and time in seconds in the formula. Use magnitudes."),
  ("Electrons from charge", "Q nElec", "+Q +n", "a=Fb",
   "Q is charge magnitude, nElec is moles of electrons. F is 96485.33212 C/mol.")
)
CONST["N"] = CONST["NA"]
CONST["U"] = 1000
CONST["P"] = 100
CONST["M"] = 1000000
CONST["L"] = CONST["L2"]
CONST["T"] = 2
CONST["I"] = 1
CONST["S"] = CONST["LIGHT"]
CONST["W"] = 10

# Teacher rules live in the OS list ECSET, shared with CHEMLAB.
# 0 magic, 1 PIN hash, 2 topics off, 3-8 tools off, 9 sig-fig items off,
# 10 answer mode, 11 work level, 12 round off, 13 fixed sf, 14 exact sf,
# 15 tie rule, 16 unit change off, 17 guides off, 18 plots off,
# 19 tolerance (0.1%), 20 tries before reveal, 21 checksum.
MAGIC = 4207
TS = [MAGIC] + [0] * 18 + [10, 3, 0]
TAMPER = False


def ts_sum(L):
  t = 12345
  for i in range(21):
    t += (i * 31 + 7) * int(L[i])
  return t % 99991


def ts_load():
  global TAMPER, ROUND_EVEN
  try:
    from ti_system import recall_list
    L = [int(x) for x in recall_list("ECSET")]
  except Exception:
    L = []
  if L:
    if len(L) == 22 and L[0] == MAGIC and ts_sum(L) == L[21]:
      TS[:] = L
      TAMPER = False
    else:
      TS[:] = [MAGIC] + [0] * 18 + [10, 3, 0]
      TS[1] = L[1] if len(L) > 1 and 0 < L[1] < 2000000 else 0
      TS[2] = 255
      TAMPER = True
  if TS[15]:
    ROUND_EVEN = TS[15] == 2


def off(i, bit):
  return (TS[i] >> bit) & 1


def on_items(i, n):
  return [j for j in range(n) if not off(i, j)]


def gv(valid):
  return [x for x in valid if x != "8" or not TS[17]]


def guide_bar():
  return "8 Guide   0 Back" if not TS[17] else "0 Back"


def work(W, revealed):
  lv = TS[11]
  if lv == 0 and not revealed:
    lv = 1
  if lv == 3:
    return ["Work is turned off by your teacher."]
  out = list(W[0])
  if lv < 2:
    out += W[1]
  if lv == 0:
    out += W[2]
  if lv < 2:
    out += W[3]
  return out


def grade(s, y):
  p = decimal(s)
  x = float(s.lower().replace("*10^", "e"))
  tol = TS[19] / 1000
  good = abs(x - y) <= tol * abs(y) if y else abs(x) < 1e-12
  if good and TS[14] and TS[13] and p[3] != TS[13]:
    return 3
  return 1 if good else 2


def verdict(r, st, last=True):
  if r == 1:
    if last:
      st[0] = True
      return "Correct. Answer unlocked."
    return "Correct. Now the next value."
  st[1] += 1
  if r == 3:
    m = "Right value, but give " + str(TS[13]) + " sig figs."
  else:
    m = "Not quite. Check your setup and units."
  n = TS[20]
  if n and st[1] >= n:
    st[0] = True
    return m + " Answer revealed after " + str(n) + " tries."
  if n:
    m += " Tries left: " + str(n - st[1])
  return m


def teacher():
  try:
    import ECTEACH
    ECTEACH.run(globals())
  except ImportError:
    page("Teacher controls")
    notice("Send ECTEACH.py to this calculator to use teacher controls.")
  except MemoryError:
    page("Low Python memory")
    notice("Restart Python, then open teacher controls first.")
  try:
    import sys
    del sys.modules["ECTEACH"]
  except Exception:
    pass
  ts_load()


def wrapped(txt):
  lines = []
  line = ""
  for word in txt.split(" "):
    if not word:
      continue
    if line and len(line) + len(word) >= 26:
      lines.append(line)
      line = ""
    while len(word) > 26:
      lines.append(word[:26])
      word = word[26:]
    if line:
      line += " "
    line += word
  if line:
    lines.append(line)
  return lines


def show(txt):
  for line in wrapped(txt):
    print(line)


def page(title):
  disp_clr()
  show(title.upper())
  print(BAR)


def select(valid, prompt="Pick: "):
  while True:
    s = input(prompt).strip()
    if s in valid:
      return s
    if not s and "0" in valid:
      return "0"
    print("Choose a listed number.")


def notice(msg, ok=False):
  show(msg)
  input("[Enter] Continue ")


def pages(title, lines):
  pos = 0
  while True:
    page(title)
    for line in lines[pos:pos+7]:
      print(line)
    nav = ["0"]
    footer = "0 Back"
    if pos:
      footer += "   1 Prev"
      nav.append("1")
    if pos + 7 < len(lines):
      footer += "   2 Next"
      nav.append("2")
    print(footer)
    s = select(nav)
    if s == "0":
      return
    pos += 7 if s == "2" else -7


def digits(txt):
  if not txt:
    return False
  for x in txt:
    if x not in DIG:
      return False
  return True


# Parse decimal spelling without converting the significand to a float.
def decimal(text):
  t = text.strip().lower().replace("*10^", "e")
  if not t or len(t) > 72:
    raise ValueError()
  neg = ""
  if t[0] in "+-":
    if t[0] == "-":
      neg = "-"
    t = t[1:]
  bits = t.split("e")
  if len(bits) > 2:
    raise ValueError()
  power = 0
  if len(bits) == 2:
    e = bits[1]
    test = e
    if e and e[0] in "+-":
      test = e[1:]
    if not digits(test) or len(test) > 4:
      raise ValueError()
    power = int(e)
    if abs(power) > 999:
      raise ValueError()
  bits = bits[0].split(".")
  if len(bits) > 2:
    raise ValueError()
  a = bits[0]
  b = bits[1] if len(bits) == 2 else ""
  raw = a + b
  if not digits(raw):
    raise ValueError()
  core = raw.lstrip("0")
  if not core:
    return ("", "", 0, 0)
  exponent = power + len(a) - (len(raw) - len(core)) - 1
  marked = "." in t or "e" in t
  count = len(core) if marked else len(core.rstrip("0"))
  return (neg, core, exponent, count)


def rounded(core, exponent, places):
  if places < 0 or not core:
    return ("0", 0)
  if not places:
    if round_up(core, 0):
      return ("1", exponent + 1)
    return ("0", 0)
  cut = core[:places]
  if len(cut) < places:
    cut += "0" * (places - len(cut))
  elif len(core) > places and round_up(core, places):
    carry = 1
    result = ""
    for i in range(places - 1, -1, -1):
      num = int(cut[i]) + carry
      result = DIG[num % 10] + result
      carry = num // 10
    if carry:
      return ("1" + "0" * (places - 1), exponent + 1)
    cut = result
  return (cut, exponent)


def round_up(core, pos):
  next_digit = core[pos]
  if next_digit != "5":
    return next_digit > "5"
  if not ROUND_EVEN or core[pos+1:].strip("0"):
    return True
  return pos > 0 and int(core[pos-1]) % 2 == 1


def fixed(core, exponent):
  pos = exponent + 1
  if pos <= 0:
    return "0." + "0" * (-pos) + core
  if pos >= len(core):
    return core + "0" * (pos - len(core))
  return core[:pos] + "." + core[pos:]


def sci(core, exponent):
  mantissa = core[0]
  if len(core) > 1:
    mantissa += "." + core[1:]
  return mantissa + "e" + str(exponent)


def sigformat(parsed, n, scientific=False):
  neg, core, exponent, count = parsed
  if not core:
    if scientific:
      return sci("0" * n, 0)
    return "0" if n == 1 else "0." + "0" * (n - 1)
  core, exponent = rounded(core, exponent, n)
  if scientific or exponent < -4 or exponent > 7:
    return neg + sci(core, exponent)
  pos = exponent + 1
  if pos > len(core) or (pos == len(core) and core[-1] == "0"):
    return neg + sci(core, exponent)
  return neg + fixed(core, exponent)


def decformat(parsed, n):
  neg, core, exponent, count = parsed
  if not core:
    return fixed("0" * (1 + n), 0)
  out, e = rounded(core, exponent, exponent + 1 + n)
  if out == "0":
    return fixed("0" * (1 + n), 0)
  digits_after = len(out) - e - 1
  if digits_after < n:
    out += "0" * (n - digits_after)
  if e < -300 or e + n > 60:
    return neg + sci(out.rstrip("0"), e)
  return neg + fixed(out, e)


def approx(x, sf=7):
  p = decimal("{:.8e}".format(x))
  if not p[1]:
    return "0"
  core, e = rounded(p[1], p[2], sf)
  core = core.rstrip("0")
  if e < -4 or e > 7:
    return p[0] + sci(core, e)
  return p[0] + fixed(core, e)


def value(x):
  return x - x == 0


def limits(kind):
  if kind[0] in "!+#@&":
    return kind[0], kind[1:]
  return "", kind


def check(x, kind):
  if not value(x):
    return "Number out of range."
  flag, code = limits(kind)
  if code == "t" and x < 0:
    return "Below absolute zero."
  if flag == "#" and (x < .99999 or x > 10000.00001 or abs(x - int(x + .5)) > .00001):
    return "Need a whole number 1-10000."
  if flag == "!" and x <= 0:
    return "Must be greater than zero."
  if flag in ("+", "@", "&") and x < 0:
    return "Must not be negative."
  if flag == "@" and x > 100:
    return "Must be 0 to 100 percent."
  if flag == "&" and x > 1:
    return "Must be between 0 and 1."
  if code == "P" and x > 1000000:
    return "Mass ratio exceeds 100%."
  return ""


def unit(kind, ix=0):
  return U[limits(kind)[1]][0].split(" ")[ix]


def scale(x, kind, ix, out=False):
  code = limits(kind)[1]
  fac = U[code][1][ix]
  if code == "t" and ix:
    if ix == 1:
      return x - 273.15 if out else x + 273.15
    # Subtract absolute zero first so its entered value maps to zero.
    return x / fac - 459.67 if out else (x + 459.67) * fac
  return x / fac if out else x * fac


def pickunit(title, name, kind):
  names = U[limits(kind)[1]][0].split(" ")
  if len(names) == 1:
    return 0
  page(title)
  show(name + " / choose unit")
  for i in range(len(names)):
    print(str(i + 1) + " " + names[i])
  print("0 Back   Enter = 1")
  while True:
    s = input("Unit: ").strip()
    if s == "0":
      return -1
    if not s:
      return 0
    for i in range(len(names)):
      if s == str(i + 1):
        return i
    print("Pick a unit number.")


def read_number(prompt):
  s = input(prompt).strip()
  if not s:
    return None
  info = decimal(s)
  x = float(s.lower().replace("*10^", "e"))
  if not value(x) or (x == 0 and info[1]):
    raise ValueError()
  return x


def field(stage, name, kind, progress=""):
  while True:
    ix = pickunit(stage, name, kind)
    if ix < 0:
      return None
    page(stage)
    show(name + (" [" + unit(kind, ix) + "]" if unit(kind, ix) else ""))
    if progress:
      print(progress)
    print("Blank Enter = Back")
    while True:
      try:
        x = read_number("Value: ")
        if x is None:
          break
        y = scale(x, kind, ix)
        err = check(y, kind)
        if not err:
          if kind[0] == "#":
            y = int(y + .5)
          return (y, x, ix)
        show(err)
      except (ValueError, OverflowError):
        print("Try -3.2 or 2.5e-3.")
    if len(U[limits(kind)[1]][1]) == 1:
      return None


def collection(title, names, kinds, skip=-1):
  ids = []
  data = [None] * len(names)
  for i in range(len(names)):
    if i != skip:
      ids.append(i)
  step = 0
  while step < len(ids):
    i = ids[step]
    got = field(title, names[i], kinds[i], "Known " + str(step+1) + "/" + str(len(ids)))
    if got is None:
      if not step:
        return None
      step -= 1
    else:
      data[i] = got
      step += 1
  return data


def product(symbols):
  if not symbols:
    return "1"
  ans = symbols[0]
  for x in symbols[1:]:
    ans += " " + x + " *"
  return ans


def law_rpn(eq, target):
  left, right = eq.replace(" ", "").split("=")
  num = []
  den = []
  sign = 0
  for pair in ((left, 1), (right, -1)):
    direction = pair[1]
    for x in pair[0]:
      if x == "/":
        direction = -direction
      elif x == target:
        sign = direction
      elif direction > 0:
        num.append(x)
      else:
        den.append(x)
  if sign > 0:
    num, den = den, num
  ans = product(num)
  if den:
    ans += " " + product(den) + " /"
  return ans


def original(eq, names):
  if not isinstance(eq, str):
    return eq[0]
  sides = []
  for side in eq.replace(" ", "").split("="):
    parts = side.split("/")
    factors = []
    for term in parts:
      fs = []
      for x in term:
        fs.append(names[ABC.index(x)] if x in ABC else ("NA" if x == "N" else x))
      factors.append(" * ".join(fs))
    if len(parts) == 2 and len(parts[1]) > 1:
      factors[1] = "(" + factors[1] + ")"
    sides.append(" / ".join(factors))
  return " = ".join(sides)


# RPN is fixed in this file; user input is never interpreted as code.
def expression(code, data, names, mode=0):
  stack = []
  for tok in code.split():
    if tok in ("+", "-", "*", "/", "^"):
      b = stack.pop()
      a = stack.pop()
      if mode:
        p = 1 if tok in ("+", "-") else (3 if tok == "^" else 2)
        sa = a[0]
        sb = b[0]
        if a[1] < p or (tok == "^" and a[1] == p):
          sa = "(" + sa + ")"
        if b[1] < p or (tok in ("-", "/", "^") and b[1] == p):
          sb = "(" + sb + ")"
        stack.append((sa + " " + tok + " " + sb, p))
      else:
        if tok == "+":
          x = a + b
        elif tok == "-":
          x = a - b
        elif tok == "*":
          x = a * b
        elif tok == "/":
          x = a / b
        else:
          x = a ** b
        stack.append(x)
    elif tok in ("ln", "lg", "neg", "exp", "sqrt"):
      a = stack.pop()
      if mode:
        if tok == "neg":
          name = "-"
        else:
          name = "log10" if tok == "lg" else tok
        stack.append((name + "(" + a[0] + ")", 4))
      else:
        if tok == "ln":
          x = log(a)
        elif tok == "lg":
          x = log10(a)
        elif tok == "exp":
          x = exp(a)
        elif tok == "sqrt":
          x = sqrt(a)
        else:
          x = -a
        stack.append(x)
    else:
      if tok in ABC and len(tok) == 1:
        i = ABC.index(tok)
        x = data[i][0]
        label = names[i]
      else:
        x = CONST[tok] if tok in CONST else float(tok)
        label = "NA" if tok == "N" else tok
      if mode == 2:
        label = approx(x)
        if x < 0:
          label = "(" + label + ")"
      stack.append((label, 4) if mode else x)
  return stack[0][0] if mode else stack[0]


def choose_unknown(title, names, kinds, eq, note):
  while True:
    page(title)
    print("Which value is missing?")
    for i in range(len(names)):
      print(str(i+1) + " " + names[i])
    print(guide_bar())
    s = select(gv(["0", "8"] + [str(i+1) for i in range(len(names))]))
    if s == "8":
      lines = wrapped(original(eq, names)) + [""] + wrapped(note) + [""]
      for i in range(len(names)):
        label = unit(kinds[i])
        if label:
          lines += wrapped(names[i] + ": " + label)
      pages("Equation guide", lines)
    else:
      return int(s)-1


def integer(prompt, low, high):
  while True:
    s = input(prompt).strip()
    if not s:
      return None
    if digits(s) and len(s) < 5:
      n = int(s)
      if low <= n <= high:
        return n
    print("Use " + str(low) + " to " + str(high) + ".")


def answer(name, kind, x, ix, formula, W):
  sf = TS[13]
  st = [TS[10] == 0, 0]
  multi = len(U[limits(kind)[1]][1]) > 1 and not TS[16]
  while True:
    page("Answer / " + name)
    if formula and TS[11] < 3:
      show(formula)
    label = unit(kind, ix)
    if st[0]:
      try:
        y = scale(x, kind, ix, True)
        if not value(y):
          num = "Unit out of range"
        elif sf:
          num = sigformat(decimal("{:.8e}".format(y)), sf)
        else:
          num = approx(y)
      except (ValueError, OverflowError):
        num = "Unit out of range"
      show("> " + num + (" " + label if label else ""))
    elif TS[10] == 1:
      show("> ? Press 3 to check your answer" + (" in " + label if label else ""))
    else:
      show("> Answer hidden by teacher")
    options = ["0", "1"]
    bar = "1 Again"
    if TS[11] < 3:
      options.append("2")
      bar += "   2 Work"
    if st[0] and not TS[12]:
      options.append("3")
      bar += "   3 Round"
    if not st[0] and TS[10] == 1:
      options.append("3")
      bar += "   3 Check"
    print(bar)
    bar = ""
    if multi:
      options.append("4")
      bar += "4 Unit   "
    print(bar + "0 Back")
    s = select(options)
    if s == "0" or s == "1":
      return s == "1"
    if s == "2":
      pages("Worked solution", work(W, st[0]))
    if s == "3" and st[0]:
      page("Round the answer")
      print("1-7 significant figures")
      print("0 = normal display")
      print("Blank Enter = Back")
      n = integer("Digits: ", 0, 7)
      if n is not None:
        sf = n
    if s == "4":
      chosen = pickunit("Answer unit", name, kind)
      if chosen >= 0:
        ix = chosen
    if s == "3" and not st[0] and TS[10] == 1:
      page("Check / " + name)
      show("Type your answer" + (" in " + label if label else "") + ".")
      print("Blank Enter = Back")
      t = input("Answer: ").strip()
      if t:
        page("Check / " + name)
        try:
          notice(verdict(grade(t, scale(x, kind, ix, True)), st))
        except (ValueError, OverflowError):
          notice("Type a number such as 2.5e-3.")


def solve(tool):
  title, labels, units, eq, note = tool
  names = labels.split()
  kinds = units.split()
  while True:
    i = choose_unknown(title, names, kinds, eq, note)
    if i < 0:
      return
    data = collection("Enter knowns", names, kinds, i)
    if data is None:
      continue
    code = law_rpn(eq, ABC[i]) if isinstance(eq, str) else eq[i+1]
    raw_factor = None
    try:
      x = expression(code, data, names)
      if title == "Formula multiplier" and i == 0 and value(x) and .97 <= x <= 10000.03:
        raw_factor = x
        x = int(x + .5)
        error = check(x, kinds[i])
        if abs(raw_factor - x) > .03:
          error = "Mass ratio is not close to a whole number."
      else:
        error = check(x, kinds[i])
    except (ZeroDivisionError, ValueError, OverflowError, TypeError):
      error = "No unique real answer. Check for zero divisors or invalid input."
    if error:
      page("Check your values")
      notice(error)
      continue
    if kinds[i][0] == "#":
      x = int(x + .5)
    ix = pickunit("Answer unit", names[i], kinds[i])
    if ix < 0:
      continue
    f = names[i] + " = " + expression(code, data, names, 1)
    sub = names[i] + " = " + expression(code, data, names, 2)
    F = wrapped("1. " + original(eq, names)) + wrapped("2. " + f)
    S = wrapped("3. " + sub)
    R = []
    if raw_factor is not None and raw_factor != x:
      R += wrapped("Raw mass ratio: " + approx(raw_factor))
    label = unit(kinds[i])
    R += wrapped("4. " + names[i] + " = " + approx(x) + " " + label)
    K = ["", "Knowns in formula units:"]
    for j in range(len(names)):
      if j != i:
        y, raw, at = data[j]
        txt = names[j] + " = " + approx(y) + " " + unit(kinds[j])
        if at:
          txt += " from " + approx(raw) + " " + unit(kinds[j], at)
        K += wrapped(txt)
    if not answer(names[i], kinds[i], x, ix, f, (F, S, R, K)):
      return


def dalton():
  page("Dalton: add pressures")
  print("How many gases? (2-6)")
  print("Blank Enter = Back")
  n = integer("Gases: ", 2, 6)
  if n is None:
    return
  names = ["Ptotal"] + ["P" + str(j) for j in range(1, n+1)]
  allparts = " + ".join(names[1:])
  f = ["Ptotal = " + allparts]
  for j in range(n+1):
    if j == 0:
      s = "b"
      for k in range(2, n+1):
        s += " " + ABC[k] + " +"
    else:
      s = "a"
      for k in range(1, n+1):
        if j != k:
          s += " " + ABC[k] + " -"
    f.append(s)
  solve(("Dalton: add pressures", " ".join(names), "!p " + "+p " * n, f,
       "Total pressure equals the sum of the partial pressures. The tool can also solve for one missing partial pressure."))


# checks: ("n", label, value) or ("p", label, options, correct index)
def report(title, lines, W, checks=()):
  st = [TS[10] == 0, 0]
  at = 0
  while True:
    page(title)
    if st[0]:
      for line in lines:
        show(line)
    elif TS[10] == 1 and checks:
      show("Results hidden. Press 3 to check your answer.")
    else:
      show("Results hidden by teacher.")
    options = ["0", "1"]
    bar = "1 Again"
    if TS[11] < 3:
      options.append("2")
      bar += "   2 Work"
    if not st[0] and TS[10] == 1 and checks:
      options.append("3")
      bar += "   3 Check"
    print(bar)
    print("0 Back")
    s = select(options)
    if s == "0" or s == "1":
      return s == "1"
    if s == "2":
      pages("Worked solution", work(W, st[0]))
      continue
    c = checks[at]
    last = at == len(checks) - 1
    page("Check / " + c[1])
    if c[0] == "p":
      for i in range(len(c[2])):
        print(str(i+1) + " " + c[2][i])
      print("0 Back")
      k = select(["0"] + [str(i+1) for i in range(len(c[2]))])
      if k == "0":
        continue
      r = 1 if int(k) - 1 == c[3] else 2
    else:
      show("Type your value for " + c[1] + ".")
      print("Blank Enter = Back")
      t = input("Answer: ").strip()
      if not t:
        continue
      try:
        r = grade(t, c[2])
      except (ValueError, OverflowError):
        page("Check / " + c[1])
        notice("Type a number such as 2.5e-3.")
        continue
    page("Check / " + c[1])
    notice(verdict(r, st, last))
    if r == 1 and not last:
      at += 1


def limiting():
  while True:
    page("Limiting reactant")
    print("Two reactants, one product")
    print("1 Given reactant moles")
    print("2 Given reactant masses")
    print(guide_bar())
    s = select(gv(("0", "1", "2", "8")))
    if s == "0":
      return
    if s == "8":
      pages("Limiting / guide", wrapped(
        "Use a balanced equation. A and B are reactants; P is your product. "
        "Enter the three whole-number coefficients. In mass mode also enter their molar masses. "
        "The smaller moles/coefficient ratio determines the product. Assumes complete reaction."))
      continue
    names = ["molA", "molB", "coefA", "coefB", "coefP"]
    kinds = ["+n", "+n", "#0", "#0", "#0"]
    if s == "2":
      names = ["massA", "massB"] + names[2:] + ["MMA", "MMB", "MMP"]
      kinds = ["+m", "+m"] + kinds[2:] + ["!w", "!w", "!w"]
    data = collection("Limiting / knowns", names, kinds)
    if data is None:
      continue
    d = [x[0] for x in data]
    a = d[0] if s == "1" else d[0] / d[5]
    b = d[1] if s == "1" else d[1] / d[6]
    ra = a / d[2]
    rb = b / d[3]
    prod = min(ra, rb) * d[4]
    g = prod * d[7] if s == "2" else 0
    if not value(prod) or not value(g):
      page("Check your values")
      notice("Result out of range.")
      continue
    who = "A" if ra < rb else "B"
    if abs(ra-rb) <= 1e-7 * max(ra, rb):
      who = "A and B (tie)"
    lines = ["Limiting: " + who, "Product: " + approx(prod) + " mol"]
    F = ["ratio = mol / coef", "molP = min(ratios) * coefP"]
    S = wrapped("molA = " + approx(a) + ", molB = " + approx(b))
    S += wrapped("molA / coefA = " + approx(ra))
    S += wrapped("molB / coefB = " + approx(rb))
    R = wrapped("Limiting: " + who) + wrapped("molP = " + approx(prod) + " mol")
    tie = 2 if who[0] == "A" and len(who) > 1 else (0 if who == "A" else 1)
    checks = [("p", "Limiting reactant", ("A", "B", "Tie"), tie),
              ("n", "product mol", prod)]
    if s == "2":
      F = ["mol = mass / molar mass"] + F + ["massP = molP * MMP"]
      lines += ["Product: " + approx(g) + " g"]
      R += wrapped("massP = " + approx(g) + " g")
      checks.append(("n", "product grams", g))
    if not report("Limiting / answer", lines, (F, S, R, []), checks):
      return


def q_vs_k():
  while True:
    page("Compare Q and K")
    print("Q = reaction quotient")
    print("K = equilibrium constant")
    print("Use the same convention.")
    print("1 Enter Q and K   0 Back")
    if select(("0", "1")) == "0":
      return
    d = collection("Equilibrium / knowns", ["Q", "K"], ["+0", "!0"])
    if d is None:
      continue
    q, k = [a[0] for a in d]
    if q < k:
      rule = "Q < K"
      text = "Net shift: toward products"
    elif q > k:
      rule = "Q > K"
      text = "Net shift: toward reactants"
    else:
      rule = "Q = K"
      text = "At equilibrium"
    F = wrapped("Compare the reaction quotient with the equilibrium constant at the same temperature.")
    S = ["Q = " + approx(q), "K = " + approx(k)]
    R = [rule, text]
    pick = 0 if q < k else (1 if q > k else 2)
    checks = [("p", "Net shift", ("Toward products", "Toward reactants", "At equilibrium"), pick)]
    if not report("Equilibrium / answer", [rule, text], (F, S, R, []), checks):
      return


def weak_acid():
  while True:
    page("Weak acid / monoprotic")
    print("HA in water, no added salt")
    print("Input Ka and initial [HA].")
    print("1 Calculate pH   0 Back")
    if select(("0", "1")) == "0":
      return
    d = collection("Weak acid / knowns", ["Ka", "Initial [HA]"], ["!0", "!c"])
    if d is None:
      continue
    ka, c = [a[0] for a in d]
    try:
      x = c / (.5 + sqrt(.25 + c / ka))
      ph = -log10(x)
      pct = 100 * (x/c)
    except (ValueError, OverflowError, ZeroDivisionError):
      page("Check your values")
      notice("Result out of range.")
      continue
    F = wrapped("Ka = x^2 / (C0 - x)") + wrapped("x = C0 / (0.5 + sqrt(0.25 + C0 / Ka))")
    F += wrapped("pH = -log10(x). Ion% = 100 * x / C0. Ignores water's own ionization; avoid near neutral or very dilute solutions.")
    S = ["Ka = " + approx(ka), "C0 = " + approx(c) + " mol/L"]
    lines = ["pH = " + approx(ph), "[H3O+] = " + approx(x) + " mol/L", "Ionized = " + approx(pct) + "%"]
    if x < 1e-6:
      lines.append("Caution: near water pH")
    if not report("Weak acid / answer", lines, (F, S, lines, []), [("n", "pH", ph)]):
      return


def ksp():
  while True:
    page("Ksp and solubility")
    print("Pure water; two ions.")
    print("Solid -> a A + b B")
    print("1 Find molar solubility")
    print("2 Find Ksp")
    print(guide_bar())
    s = select(gv(("0", "1", "2", "8")))
    if s == "0":
      return
    if s == "8":
      pages("Ksp / guide", wrapped(
        "Use a and b from the balanced dissolution. Example: CaF2 gives a=1 and b=2. "
        "Use s in mol/L. No preexisting common ions, pH effects or complex formation."))
      continue
    d = collection("Ksp / knowns", ["a", "b", "Ksp" if s == "1" else "Solubility s"],
             ["#0", "#0", "!0" if s == "1" else "!c"])
    if d is None:
      continue
    a, b, x = [i[0] for i in d]
    name = "Solubility" if s == "1" else "Ksp"
    kind = "!c" if s == "1" else "!0"
    f = "ln(s) = (ln(Ksp) - a*ln(a) - b*ln(b)) / (a + b)" if s == "1" else "Ksp = (a*s)^a * (b*s)^b"
    try:
      if s == "1":
        y = exp((log(x) - a*log(a) - b*log(b)) / (a+b))
      else:
        y = exp(a*(log(a)+log(x)) + b*(log(b)+log(x)))
    except (ValueError, OverflowError):
      y = 0
    if not value(y) or y <= 0:
      page("Check your values")
      notice("Result out of range.")
      continue
    ix = pickunit("Answer unit", name, kind)
    if ix < 0:
      continue
    F = wrapped("Ksp = (a*s)^a * (b*s)^b") + wrapped(f)
    S = wrapped("a = " + approx(a) + ", b = " + approx(b))
    S += wrapped(("Ksp = " if s == "1" else "s (mol/L) = ") + approx(x))
    R = wrapped(name + " = " + approx(y) + (" mol/L" if s == "1" else ""))
    if not answer(name, kind, y, ix, f, (F, S, R, [])):
      return


def atom_weights():
  # CIAAW abridged weights; 207.2 is the conventional classroom Pb value.
  # A dash means no standard weight; request an isotope-specific value.
  text = (
    "H:1.008 He:4.0026 Li:6.94 Be:9.0122 B:10.81 C:12.011 N:14.007 O:15.999 F:18.998 Ne:20.180 "
    "Na:22.990 Mg:24.305 Al:26.982 Si:28.085 P:30.974 S:32.06 Cl:35.45 Ar:39.95 K:39.098 Ca:40.078 "
    "Sc:44.956 Ti:47.867 V:50.942 Cr:51.996 Mn:54.938 Fe:55.845 Co:58.933 Ni:58.693 Cu:63.546 Zn:65.38 "
    "Ga:69.723 Ge:72.630 As:74.922 Se:78.971 Br:79.904 Kr:83.798 Rb:85.468 Sr:87.62 Y:88.906 Zr:91.222 "
    "Nb:92.906 Mo:95.95 Tc:- Ru:101.07 Rh:102.91 Pd:106.42 Ag:107.87 Cd:112.41 In:114.82 Sn:118.71 "
    "Sb:121.76 Te:127.60 I:126.90 Xe:131.29 Cs:132.91 Ba:137.33 La:138.91 Ce:140.12 Pr:140.91 Nd:144.24 "
    "Pm:- Sm:150.36 Eu:151.96 Gd:157.25 Tb:158.93 Dy:162.50 Ho:164.93 Er:167.26 Tm:168.93 Yb:173.05 "
    "Lu:174.97 Hf:178.49 Ta:180.95 W:183.84 Re:186.21 Os:190.23 Ir:192.22 Pt:195.08 Au:196.97 Hg:200.59 "
    "Tl:204.38 Pb:207.2 Bi:208.98 Po:- At:- Rn:- Fr:- Ra:- Ac:- Th:232.04 Pa:231.04 U:238.03 "
    "Np:- Pu:- Am:- Cm:- Bk:- Cf:- Es:- Fm:- Md:- No:- Lr:- Rf:- Db:- Sg:- Bh:- Hs:- Mt:- Ds:- "
    "Rg:- Cn:- Nh:- Fl:- Mc:- Lv:- Ts:- Og:-"
  )
  result = {}
  for pair in text.split():
    symbol, mass = pair.split(":")
    result[symbol] = 0 if mass == "-" else float(mass)
  return result


def atom_count(s, i):
  j = i
  while j < len(s) and s[j] in DIG:
    j += 1
  if i == j:
    return 1, j
  if j-i > 4 or s[i] == "0":
    raise ValueError("Use subscripts 1-9999.")
  return int(s[i:j]), j


def add_atoms(dest, src, multiplier):
  for symbol in src:
    dest[symbol] = dest.get(symbol, 0) + src[symbol] * multiplier
    if dest[symbol] > 1000000:
      raise ValueError("Atom count too large.")


def parse_formula(text, weights):
  text = text.strip()
  if not text or len(text) > 54:
    raise ValueError("Use 1-54 characters.")
  result = {}
  parts = text.split(".")
  for part_idx in range(len(parts)):
    s = parts[part_idx]
    m, i = atom_count(s, 0)
    if (not part_idx and i) or i == len(s):
      raise ValueError("Use a formula, e.g. H2O.")
    counts = [{}]
    opens = []
    while i < len(s):
      c = s[i]
      if c in "([":
        counts.append({})
        opens.append(c)
        i += 1
      elif c in ")]":
        if not opens or not counts[-1] or opens[-1] != ("(" if c == ")" else "["):
          raise ValueError("Check group brackets.")
        opens.pop()
        g = counts.pop()
        factor, i = atom_count(s, i+1)
        add_atoms(counts[-1], g, factor)
      elif "A" <= c <= "Z":
        sym = c
        i += 1
        if i < len(s) and "a" <= s[i] <= "z":
          sym += s[i]
          i += 1
        if sym not in weights:
          raise ValueError("Unknown element: " + sym)
        if not weights[sym]:
          raise ValueError("No standard weight for " + sym + ". Use an isotope mass.")
        n, i = atom_count(s, i)
        add_atoms(counts[-1], {sym: n}, 1)
      else:
        raise ValueError("Check case and formula.")
    if opens or not counts[0]:
      raise ValueError("Check group brackets.")
    add_atoms(result, counts[0], m)
  return result


def molar_mass():
  weights = atom_weights()
  while True:
    page("Molar mass / formula")
    print("Use correct letter case.")
    print("Try H2O or Ca(OH)2")
    print("Hydrates: CuSO4.5H2O")
    print("Blank Enter = Back")
    txt = input("Formula: ").strip()
    if not txt:
      return
    try:
      atoms = parse_formula(txt, weights)
    except ValueError as e:
      notice(str(e))
      continue
    total = 0
    S = []
    for symbol in sorted(atoms):
      amt = atoms[symbol] * weights[symbol]
      total += amt
      S += wrapped(symbol + ": " + str(atoms[symbol]) + " * " +
               approx(weights[symbol]) + " = " + approx(amt))
    R = wrapped("Total = " + approx(total) + " g/mol")
    W = (["Mass = sum(count * weight)"], S, R, [])
    if not answer("Molar mass", "!w", total, 0, "", W):
      return


def convert():
  choices = (
    ("Temperature", "t"), ("Temperature change", "d"), ("Volume", "v"),
    ("Pressure", "p"), ("Mass", "m"), ("Amount", "n"), ("Energy", "q"),
    ("Molar energy", "h"), ("Molarity", "c"), ("Time", "z"), ("Length", "l"),
    ("Density", "D"), ("Molar mass", "w"), ("Voltage", "V")
  )
  at = 0
  while True:
    i = list_menu("Unit conversions", [a[0] for a in choices], at)
    if i < 0:
      return
    at = i
    name, kind = choices[i]
    if kind not in "dtqhV":
      kind = "+" + kind
    while True:
      d = field("Convert / input", name, kind)
      if d is None:
        break
      x, raw, i = d
      to = pickunit("Convert / output", name, kind)
      if to < 0:
        continue
      S = wrapped("Input = " + approx(raw) + " " + unit(kind, i))
      R = wrapped("Base = " + approx(x) + " " + unit(kind))
      if not answer(name, kind, x, to, "", ([], S, R, [])):
        break


def round_tool(mode):
  while True:
    title = ("Round to sig figs", "Round decimal places", "Count sig figs", "Scientific notation")[mode]
    page(title)
    print("Enter a number, e.g.")
    print("-1.245 or 2.50e-3")
    print("Blank Enter = Back")
    raw = input("Number: ").strip()
    if not raw:
      return
    try:
      p = decimal(raw)
    except ValueError:
      notice("Use a number, not a formula. No commas. Example: -2.5e-3")
      continue
    if mode != 2:
      n = integer("Places (0-12): " if mode == 1 else "Sig figs (1-15): ",
            0 if mode == 1 else 1, 12 if mode == 1 else 15)
      if n is None:
        continue
    page(title)
    if mode == 2:
      if not p[1]:
        print("Input is exactly zero.")
        show("Zeros after the point show precision in decimal places.")
      else:
        print("> " + str(p[3]) + " significant figures")
        if "." not in raw and "e" not in raw.lower() and "*10^" not in raw and raw[-1] == "0":
          show("Trailing whole-number zeros are treated as placeholders.")
    else:
      text = decformat(p, n) if mode == 1 else sigformat(p, n, mode == 3)
      show("> " + text)
      if "e" in text and mode == 1:
        show("Too long for fixed notation.")
    print("1 Again   0 Back")
    if select(("0", "1")) == "0":
      return


def list_menu(title, names, at=0):
  pos = at // 7 * 7
  while True:
    page(title)
    stop = min(pos+7, len(names))
    nav = ["0"]
    for i in range(pos, stop):
      n = str(i-pos+1)
      print(n + " " + names[i])
      nav.append(n)
    bar = "0 Back"
    if stop < len(names):
      nav.append("8")
      bar = "8 Next   " + bar
    if pos:
      nav.append("9")
      bar = "9 Prev   " + bar
    print(bar)
    s = select(nav)
    if s == "8":
      pos += 7
    elif s == "9":
      pos -= 7
    elif s == "0":
      return -1
    else:
      return pos+int(s)-1


def round_menu():
  global ROUND_EVEN
  names = ("Round to sig figs", "Round decimal places", "Count sig figs",
       "Scientific notation", "Convert units", "Rounding guide", "Tie rounding rule")
  while True:
    ids = on_items(9, 7)
    if TS[15] and 6 in ids:
      ids.remove(6)
    if not ids:
      page("Sig figs and units")
      notice("Your teacher has turned these tools off.")
      return
    i = list_menu("Sig figs and units", [names[j] for j in ids])
    if i < 0:
      return
    i = ids[i]
    if i < 4:
      round_tool(i)
    elif i == 4:
      convert()
    elif i == 6:
      page("Tie rounding rule")
      print("Now: " + ("even" if ROUND_EVEN else "away from zero"))
      print("1 Half away from zero")
      print("2 Half to even")
      print("0 Keep current")
      s = select(("0", "1", "2"))
      if s != "0":
        ROUND_EVEN = s == "2"
    else:
      pages("Rounding / guide", wrapped(
        "Enter a decimal or scientific notation such as 2.50e-3. "
        "Enter requested digits. Exact ties round away from zero by default. "
        "Use Tie rounding rule for half to even, if your class uses it. "
        "1200 counts as 2 sig figs; 1200. and 1.200e3 count as 4. "
        "For multiply/divide, use the fewest sig figs. For add/subtract, use the fewest decimal places. "
        "Keep guard digits until the final result. For log problems, use your class's log precision rule."))


SPECIAL = {
  "Dalton: add pressures": dalton, "Limiting reactant": limiting,
  "Molar mass formula": molar_mass, "Weak acid (1 proton)": weak_acid,
  "Compare Q and K": q_vs_k, "Ksp and solubility": ksp
}


def main():
  ts_load()
  topics = ("Gas laws", "Moles and reactions", "Solutions and pH", "Heat and energy",
        "Rates and equilibrium", "Light and electrochem", "Sig figs and units")
  groups = (GAS, MOLES, SOLN, HEAT, RATE, MORE)
  while True:
    page("E A S Y   C H E M")
    if TAMPER:
      print("Rules damaged: see teacher")
    valid = ["0", "8", "9"]
    for i in range(len(topics)):
      if not off(2, i):
        print(str(i+1) + " " + topics[i])
        valid.append(str(i+1))
    if len(valid) == 3:
      print("All topics locked.")
    print("8 Help   9 Teacher   0 Exit")
    s = select(valid)
    if s == "9":
      teacher()
      continue
    if s == "0":
      page("Easy Chem")
      print("Done. See you next lab!")
      return
    if s == "8":
      pages("Quick start", wrapped(
        "Type a menu number, then ENTER. Pick a topic and equation. "
        "8 Guide on a solver shows the rule and when to use it. "
        "Pick the missing value, choose units, then enter known numbers. "
        "At a value prompt, blank ENTER goes back. At unit selection blank ENTER picks option 1. "
        "Try 2.5e-3 for small values. On the answer, 2 Work shows rearranged formula and substitution, "
        "and 3 Round sets significant figures. Only round at the end. "
        "Your teacher may hide answers, work or tools. In check mode press 3 Check and type your answer. "
        "Teachers: press 9 on the main menu."))
    elif s == "7":
      round_menu()
    else:
      n = int(s)-1
      group = groups[n]
      ids = on_items(3 + n, len(group))
      if not ids:
        page(topics[n])
        notice("Your teacher has turned these tools off.")
        continue
      titles = [group[j][0] for j in ids]
      at = 0
      while True:
        j = list_menu(topics[n], titles, at)
        if j < 0:
          break
        at = j
        tool = group[ids[j]]
        if tool[0] in SPECIAL:
          SPECIAL[tool[0]]()
        else:
          solve(tool)


main()
