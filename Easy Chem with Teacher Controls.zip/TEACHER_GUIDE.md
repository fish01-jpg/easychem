# Easy Chem Teacher Controls

## Files to send to the calculator
- Plus CE (terminal): `EASYCHEM.py` + `ECTEACH.py`
- Evo UI: `CHEMLAB.py`, `CHEMBOOK.py`, `CHEMREF.py` + `ECTEACH.py`

Both programs share the same rules (saved in the calculator list `ECSET`), so setting them in one program applies to both.

## Opening the controller
- Plus CE: main menu, press `9 Teacher`.
- Evo: home screen, press `9`.
- First time: create a 4 to 8 digit PIN. After that, the PIN is required (3 tries).

## What you can control
- Presets: Open practice, Homework check, Quiz/test, Setup coach, Lockdown.
- Topics on/off: hide whole topics (and the periodic table on Evo).
- Tools on/off: turn off single solvers in each topic, plus sig-fig menu items.
- Answers: Show answer, Check my answer (student types the answer first), or Hide answer. Also the check tolerance (5 to 100 tenths of a percent) and how many wrong tries before the answer is shown (0 = never).
- Work: Full work, Setup only, Formula only, or None. Full work only appears after the student gets the answer right in check mode.
- Rounding: turn off the Round button, force a sig-fig count, require exact sig figs when checking, and fix the tie rule (round half away or half even).
- Student aids: guides, unit changes, gas law plots.
- PIN and reset: change or remove the PIN, reset everything, view a summary.

## Student view
- In check mode the answer screen shows `3 Check`. After a correct answer, `3` becomes Round.
- Locked topics are hidden (Plus CE) or dimmed as "Locked by teacher" (Evo).

## Limits
- If someone edits the `ECSET` list by hand, the programs detect it, lock all topics, and show "Rules damaged / see teacher". You will get a notice next time you log in.
- Deleting the `ECSET` list resets the calculator to open rules with no PIN. Use exam mode or check calculators if that matters for a test.
- The PIN shows on screen while typing, so enter it privately.
