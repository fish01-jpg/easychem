# Easy Chem | Teacher controls (shared by EASYCHEM and CHEMLAB)
import gc as _gc
exec('''MAGIC=4207
TOPIC_NAMES=("Gas laws","Moles and reactions","Solutions and pH","Heat and energy",
 "Rates and equilibrium","Light and electrochem","Sig figs and units","Periodic table (Evo)")
GROUP_TOOLS=(
 "Charles: V and T|Boyle: P and V|Gay-Lussac: P and T|Combined gas law|Ideal gas law|Avogadro: V and n|Dalton: add pressures|Partial pressure|Gas density|Graham: effusion|Gas molar mass",
 "Mass and moles|Moles and particles|Density|Mole ratio|Grams to grams|Limiting reactant|Percent yield|Mass composition|Molar mass formula|Formula multiplier",
 "Molarity|Dilution|Titration|pH and H3O+|pOH and OH-|pH + pOH = 14|Buffer pH|Molality|Mole fraction|Mass percent|Volume percent|Mass ppm / ppb|Ka, Kb and Kw|pKa and Ka|Weak acid (1 proton)|Mass/volume percent|pH + pOH = pKw",
 "Heat: q = mc*dT|Change in temperature|Heat capacity|Phase change / mol|Gibbs free energy|Entropy: qrev / T|First law: dU = q+w|Pressure-volume work|Bond energy estimate",
 "Zero-order rate|First-order rate|Second-order rate|Half-life: 1st order|Half-life: 0 order|Half-life: 2nd order|Arrhenius|Kp and Kc|Gibbs and equilibrium|Compare Q and K|Ksp and solubility",
 "Light: wavelength/freq|Photon energy|Photon E/wavelength|Beer-Lambert|Cell voltage|Cell free energy|Nernst equation|Electric charge|Electrons from charge",
 "Round to sig figs|Round decimal places|Count sig figs|Scientific notation|Convert units|Rounding guide|Tie rounding rule"
 )
ANS_NAMES=("Show answer","Check my answer","Hide answer")
WORK_NAMES=("Full work","Setup only","Formula only","No work")
TIE_NAMES=("Student choice","Half away from 0","Half to even")
TOLS=(5,10,20,50,100)
TRIES=(0,1,2,3,5,10)
def cs(L):
 t=12345
 for i in range(21):
  t+=(i*31+7)*int(L[i])
 return t%99991
def pin_hash(s):
 h=5381
 for c in s:
  h=(h*33+ord(c))%1000003
 return h+len(s)*7+1
def fresh():
 return [MAGIC]+[0]*18+[10,3,0]
''',globals())
_gc.collect()
exec('''def onoff(v):
 return "off" if v else "on"
def tries_txt(n):
 return "never" if not n else str(n)+" wrong"
def ask_pin(title,prompt):
 page(title)
 show("PIN = 4 to 8 digits.")
 print("Blank Enter = Back")
 s=input(prompt).strip()
 if not s:
  return None
 for c in s:
  if c not in "0123456789":
   page(title)
   notice("Use digits only.")
   return ""
 if len(s)<4 or len(s)>8:
  page(title)
  notice("Use 4 to 8 digits.")
  return ""
 return s
def new_pin(T):
 a=ask_pin("Teacher PIN / new","New PIN: ")
 if not a:
  return False
 b=ask_pin("Teacher PIN / repeat","Repeat PIN: ")
 if b!=a:
  page("Teacher PIN")
  notice("PINs did not match. Nothing changed.")
  return False
 T[1]=pin_hash(a)
 return True
def login(T):
 if not T[1]:
  page("Teacher setup")
  show("No PIN yet. Create one to lock the rules.")
  print("1 Create PIN   0 Back")
  if select(("0","1"))!="1":
   return False
  return new_pin(T)
 for n in range(3):
  s=ask_pin("Teacher login","Teacher PIN: ")
  if s is None:
   return False
  if s and pin_hash(s)==T[1]:
   return True
  if s:
   page("Teacher login")
   notice("Wrong PIN. "+str(2-n)+" tries left.")
 return False
''',globals())
_gc.collect()
exec('''def pick_one(title,names,cur):
 L=[(">" if i==cur else " ")+" "+names[i] for i in range(len(names))]
 i=MENU(title,L,cur)
 return cur if i<0 else i
def bits_menu(T,ix,title,names):
 at=0
 while True:
  L=["All on","All off"]
  for j in range(len(names)):
   L.append(("-" if (T[ix]>>j)&1 else "+")+names[j])
  i=MENU(title+" (+on -off)",L,at)
  if i<0:
   return
  at=i
  if i==0:
   T[ix]=0
  elif i==1:
   T[ix]=(1<<len(names))-1
  else:
   T[ix]^=1<<(i-2)
def tools_menu(T):
 at=0
 while True:
  i=MENU("Tools on/off",list(TOPIC_NAMES[:7]),at)
  if i<0:
   return
  at=i
  names=GROUP_TOOLS[i].split("|")
  bits_menu(T,9 if i==6 else 3+i,TOPIC_NAMES[i],names)
def cyc(v,seq):
 for k in range(len(seq)):
  if seq[k]==v:
   return seq[(k+1)%len(seq)]
 return seq[0]
''',globals())
_gc.collect()
exec('''def answers_menu(T):
 at=0
 while True:
  L=["Mode: "+ANS_NAMES[T[10]],
   "Tolerance: "+str(T[19]/10)+"%",
   "Reveal after: "+tries_txt(T[20]),
   "Mode guide"]
  i=MENU("Answers",L,at)
  if i<0:
   return
  at=i
  if i==0:
   T[10]=pick_one("Answer mode",ANS_NAMES,T[10])
  elif i==1:
   T[19]=cyc(T[19],TOLS)
  elif i==2:
   T[20]=cyc(T[20],TRIES)
  else:
   pages("Answer modes",wrapped(
    "Show answer: the solver gives the result. "
    "Check my answer: the result is hidden until the student types a value within the tolerance. "
    "After the set number of wrong tries the answer is revealed; never keeps it hidden. "
    "Hide answer: no result is shown at all, for setup practice.")+[""]+wrapped(
    "Full work is only shown after the answer is unlocked. Before that, Full work acts like Setup only."))
def work_menu(T):
 page("Work display")
 T[11]=pick_one("Work display",WORK_NAMES,T[11])
''',globals())
_gc.collect()
exec('''def round_menu_t(T):
 at=0
 while True:
  L=["Round button: "+onoff(T[12]),
   "Fixed sig figs: "+(str(T[13]) if T[13] else "none"),
   "Exact sig figs: "+("required" if T[14] else "not checked"),
   "Tie rule: "+TIE_NAMES[T[15]]]
  i=MENU("Rounding rules",L,at)
  if i<0:
   return
  at=i
  if i==0:
   T[12]^=1
  elif i==1:
   T[13]=(T[13]+1)%8
  elif i==2:
   T[14]^=1
  else:
   T[15]=pick_one("Tie rule",TIE_NAMES,T[15])
def aids_menu(T):
 at=0
 while True:
  L=["Equation guides: "+onoff(T[17]),
   "Change answer unit: "+onoff(T[16]),
   "Gas plots: "+onoff(T[18])]
  i=MENU("Student aids",L,at)
  if i<0:
   return
  at=i
  T[(17,16,18)[i]]^=1
''',globals())
_gc.collect()
exec('''def preset(T):
 L=["Open practice","Homework check","Quiz / test","Setup coach","Lockdown"]
 i=MENU("Presets",L,0)
 if i<0:
  return
 if i==0:
  p=T[1]
  T[:]=fresh()
  T[1]=p
 elif i==1:
  T[10],T[11],T[20],T[17],T[12]=1,1,3,0,0
 elif i==2:
  T[10],T[11],T[20],T[17],T[16],T[18],T[12]=1,3,0,1,1,1,1
 elif i==3:
  T[10],T[11]=2,1
 else:
  T[2]=127
 page("Presets")
 notice(L[i]+" applied. Review the menus, then Save.",True)
def summary(T):
 L=["Answers: "+ANS_NAMES[T[10]],"Work: "+WORK_NAMES[T[11]],
  "Tolerance: "+str(T[19]/10)+"%","Reveal: "+tries_txt(T[20]),
  "Round button: "+onoff(T[12]),"Fixed sig figs: "+(str(T[13]) if T[13] else "none"),
  "Exact sig figs: "+("yes" if T[14] else "no"),"Tie: "+TIE_NAMES[T[15]],
  "Guides: "+onoff(T[17]),"Unit change: "+onoff(T[16]),"Plots: "+onoff(T[18]),""]
 for i in range(8):
  L.append(TOPIC_NAMES[i]+": "+onoff((T[2]>>i)&1))
 pages("Rule summary",L)
''',globals())
_gc.collect()
exec('''def pin_menu(T):
 at=0
 while True:
  i=MENU("PIN and reset",["Change PIN","Remove PIN (open)","Reset all rules","View summary"],at)
  if i<0:
   return
  at=i
  if i==0:
   if new_pin(T):
    page("Teacher PIN")
    notice("PIN changed. Save to keep it.",True)
  elif i==1:
   T[1]=0
   page("Teacher PIN")
   notice("PIN removed. Anyone can open teacher controls until a new PIN is set.")
  elif i==2:
   p=T[1]
   T[:]=fresh()
   T[1]=p
   page("Reset")
   notice("All rules reset to open practice. PIN kept.",True)
  else:
   summary(T)
def save(T,api):
 T[21]=cs(T)
 try:
  from ti_system import store_list
  store_list("ECSET",T)
  ok=True
 except Exception:
  ok=False
 api["TS"][:]=T
 return ok
''',globals())
_gc.collect()
exec('''def run(api):
 global MENU
 for k in ("page","print","show","select","input","notice","pages","wrapped"):
  if k in api:
   globals()[k]=api[k]
 MENU=api.get("tmenu") or api["list_menu"]
 T=[int(x) for x in api["TS"]]
 if not login(T):
  return
 if api.get("TAMPER"):
  page("Teacher controls")
  notice("Saved rules were edited outside Easy Chem, so all topics were locked and other rules reset. Review the menus, then Save.")
 at=0
 while True:
  L=["Presets","Topics on/off","Tools on/off","Answers: "+ANS_NAMES[T[10]],
   "Work: "+WORK_NAMES[T[11]],"Rounding rules","Student aids","PIN and reset",
   "Save and exit","Exit, don't save"]
  i=MENU("Teacher controls",L,at)
  if i==9:
   return
  if i<0 or i==8:
   ok=save(T,api)
   page("Teacher controls")
   notice("Rules saved and active." if ok else "Rules active until Python closes (could not save list).",ok)
   return
  at=i
  if i==0:
   preset(T)
  elif i==1:
   bits_menu(T,2,"Topics",TOPIC_NAMES)
  elif i==2:
   tools_menu(T)
  elif i==3:
   answers_menu(T)
  elif i==4:
   work_menu(T)
  elif i==5:
   round_menu_t(T)
  elif i==6:
   aids_menu(T)
  else:
   pin_menu(T)
''',globals())
_gc.collect()
